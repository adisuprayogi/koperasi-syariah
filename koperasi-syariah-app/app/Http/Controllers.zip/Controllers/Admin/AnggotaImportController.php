<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Anggota;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\AnggotaImportErrorExport;
use Maatwebsite\Excel\Concerns\ToArray;

class AnggotaImportController extends Controller
{
    /**
     * Display anggota list
     */
    public function index()
    {
        $anggota = Anggota::with('user')->latest()->paginate(20);
        return view('admin.anggota.index', compact('anggota'));
    }

    /**
     * Display import form
     */
    public function create()
    {
        return view('admin.anggota.import-tailwind');
    }

    /**
     * Download template Excel
     */
    public function downloadTemplate()
    {
        return Excel::download(new \App\Exports\AnggotaTemplateExport, 'template_import_anggota.xlsx');
    }

    /**
     * Process Excel import
     */
    public function import(Request $request)
    {
        $request->validate([
            'excel_file' => 'required|mimes:xlsx,xls|max:10240' // Max 10MB
        ]);

        try {
            $import = new class implements ToArray {
                public $data = [];
                public $errors = [];
                public $successCount = 0;
                public $errorCount = 0;

                public function array(array $array)
                {
                    $this->data = $array;
                }
            };

            Excel::import($import, $request->file('excel_file'));

            $data = $import->data;
            $errors = [];
            $successCount = 0;
            $errorCount = 0;

            // Skip header row
            $dataRows = array_slice($data, 1);

            DB::beginTransaction();

            try {
                foreach ($dataRows as $index => $row) {
                    $rowIndex = $index + 2; // +2 because Excel starts at 1 and we skip header

                    // Validasi required fields
                    if (empty($row[0]) || empty($row[8]) || empty($row[9]) || empty($row[11])) {
                        $errors[] = [
                            'row' => $rowIndex,
                            'error' => 'Nama lengkap, email, password, dan NIK wajib diisi',
                            'data' => $row
                        ];
                        $errorCount++;
                        continue;
                    }

                    // Validasi format
                    $errors_in_row = [];

                    if (!in_array($row[1], ['L', 'P'])) {
                        $errors_in_row[] = 'Jenis kelamin harus L atau P';
                    }

                    // Validasi tanggal
                    if (!empty($row[3]) && !strtotime($row[3])) {
                        $errors_in_row[] = 'Format tanggal tidak valid (gunakan YYYY-MM-DD)';
                    }

                    // Validasi penghasilan
                    if (!empty($row[7]) && !is_numeric($row[7])) {
                        $errors_in_row[] = 'Penghasilan harus angka';
                    }

                    // Validasi email
                    if (!filter_var($row[8], FILTER_VALIDATE_EMAIL)) {
                        $errors_in_row[] = 'Format email tidak valid';
                    }

                    // Cek email sudah ada
                    if (User::where('email', $row[8])->exists()) {
                        $errors_in_row[] = 'Email sudah terdaftar';
                    }

                    // Validasi format nomor anggota (jika diisi manual)
                    if (!empty($row[10])) {
                        // Validasi format manual: YYMM.00001
                        if (!preg_match('/^\d{4}\.\d{5}$/', $row[10])) {
                            $errors_in_row[] = 'Format nomor anggota manual harus YYMM.00001 (contoh: 2512.00001)';
                        } else {
                            // Validasi YY (tahun) harus valid
                            $yy = substr($row[10], 0, 2);
                            $current_yy = date('y');
                            if ($yy < $current_yy - 5 || $yy > $current_yy + 5) {
                                $errors_in_row[] = 'Tahun pada nomor anggota tidak valid (YY harus sekitar tahun sekarang)';
                            }

                            // Cek nomor anggota sudah ada
                            if (Anggota::where('no_anggota', $row[10])->exists()) {
                                $errors_in_row[] = 'Nomor anggota sudah terdaftar';
                            }
                        }
                    }

                    // Cek NIK sudah ada
                    if (Anggota::where('nik', $row[11])->exists()) {
                        $errors_in_row[] = 'NIK sudah terdaftar';
                    }

                    // Validasi format NIK (16 digit)
                    if (!is_numeric($row[11]) || strlen($row[11]) != 16) {
                        $errors_in_row[] = 'NIK harus 16 digit angka';
                    }

                    if (!empty($errors_in_row)) {
                        $errors[] = [
                            'row' => $rowIndex,
                            'error' => implode(', ', $errors_in_row),
                            'data' => $row
                        ];
                        $errorCount++;
                        continue;
                    }

                    // Create user
                    $user = User::create([
                        'name' => $row[0],
                        'email' => $row[8],
                        'password' => Hash::make($row[9]),
                        'role' => 'anggota',
                        'email_verified_at' => now()
                    ]);

                    // Generate nomor anggota (manual atau auto)
                    if (empty($row[10])) {
                        $noAnggota = Anggota::generateNoAnggota(); // Auto-generate
                    } else {
                        $noAnggota = $row[10]; // Gunakan manual input (sudah divalidasi)
                    }

                    // Create anggota
                    $anggotaData = [
                        'user_id' => $user->id,
                        'no_anggota' => $noAnggota,
                        'nama_lengkap' => $row[0],
                        'nik' => $row[11],
                        'jenis_kelamin' => $row[1] ?? 'L',
                        'tempat_lahir' => $row[2] ?? '',
                        'tanggal_lahir' => !empty($row[3]) ? date('Y-m-d', strtotime($row[3])) : null,
                        'alamat_lengkap' => $row[4] ?? '',
                        'no_hp' => $row[5] ?? '',
                        'email' => $row[8],
                        'pekerjaan' => $row[6] ?? '',
                        'penghasilan' => !empty($row[7]) ? (string)$row[7] : '0',
                        'no_npwp' => $row[12] ?? null,
                        'status_keanggotaan' => 'aktif',
                        'jenis_anggota' => 'biasa',
                        'tanggal_gabung' => now()
                    ];

                    // Jika ada foto anggota (optional) di kolom M
                    if (isset($row[13]) && !empty($row[13])) {
                        $anggotaData['foto'] = $row[13];
                    }

                    Anggota::create($anggotaData);
                    $successCount++;
                }

                DB::commit();

                // Return to view with results
                return redirect()->route('pengurus.anggota.import')
                    ->with('success', "Berhasil mengimport $successCount data anggota")
                    ->with('error_count', $errorCount)
                    ->with('import_errors', $errors);

            } catch (\Exception $e) {
                DB::rollback();
                throw $e;
            }

        } catch (\Exception $e) {
            return redirect()->back()
                ->with('error', 'Terjadi kesalahan saat import: ' . $e->getMessage())
                ->withInput();
        }
    }

    /**
     * Download error report
     */
    public function downloadErrorReport(Request $request)
    {
        $errors = session('import_errors', []);

        if (empty($errors)) {
            return redirect()->back()->with('error', 'Tidak ada error untuk didownload');
        }

        $filename = 'error_report_import_' . date('Y-m-d_H-i-s') . '.xlsx';

        return Excel::download(new AnggotaImportErrorExport($errors), $filename);
    }
}